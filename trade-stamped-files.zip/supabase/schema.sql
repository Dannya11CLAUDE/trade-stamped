-- Trade Stamped starter schema for Supabase (Postgres)
-- Run in Supabase SQL Editor only after creating a new project.
-- Reviews default to pending; never publish unmoderated reviews automatically.

create extension if not exists pgcrypto;

create type public.review_status as enum ('pending', 'published', 'rejected', 'under_review');
create type public.business_status as enum ('draft', 'published', 'suspended');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 100),
  role text not null default 'customer' check (role in ('customer','tradesperson','admin')),
  created_at timestamptz not null default now()
);

create table public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  business_name text not null check (char_length(business_name) between 2 and 140),
  trade text not null,
  description text not null default '' check (char_length(description) <= 2000),
  town text not null,
  postcode_area text,
  phone text,
  website text,
  indicative_min_gbp integer check (indicative_min_gbp is null or indicative_min_gbp >= 0),
  indicative_max_gbp integer check (indicative_max_gbp is null or indicative_max_gbp >= 0),
  status public.business_status not null default 'draft',
  verification_label text,
  verification_checked_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (indicative_min_gbp is null or indicative_max_gbp is null or indicative_max_gbp >= indicative_min_gbp)
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete restrict,
  rating integer not null check (rating between 1 and 5),
  job_description text not null check (char_length(job_description) between 3 and 160),
  review_text text not null check (char_length(review_text) between 20 and 3000),
  status public.review_status not null default 'pending',
  business_reply text check (business_reply is null or char_length(business_reply) <= 2000),
  replied_at timestamptz,
  moderation_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index businesses_public_search_idx on public.businesses (status, trade, town);
create index reviews_public_idx on public.reviews (business_id, status, created_at desc);
create index reviews_author_idx on public.reviews (author_id, created_at desc);

create table public.review_reports (
  id uuid primary key default gen_random_uuid(),
  review_id uuid not null references public.reviews(id) on delete cascade,
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null check (char_length(reason) between 5 and 1000),
  created_at timestamptz not null default now(),
  unique (review_id, reporter_id)
);

alter table public.profiles enable row level security;
alter table public.businesses enable row level security;
alter table public.reviews enable row level security;
alter table public.review_reports enable row level security;

-- Public can read published business profiles only.
create policy "Public can view published businesses"
  on public.businesses for select using (status = 'published');
create policy "Owners can view their own businesses"
  on public.businesses for select to authenticated using (owner_id = auth.uid());
create policy "Owners can create business drafts"
  on public.businesses for insert to authenticated
  with check (owner_id = auth.uid() and status = 'draft');
create policy "Owners can update their own business drafts"
  on public.businesses for update to authenticated
  using (owner_id = auth.uid() and status = 'draft')
  with check (owner_id = auth.uid() and status = 'draft');

-- A visitor sees published reviews only. Authors can see their own pending reviews.
create policy "Public can view published reviews"
  on public.reviews for select using (status = 'published');
create policy "Authors can view their own reviews"
  on public.reviews for select to authenticated using (author_id = auth.uid());
create policy "Signed in customers can submit pending reviews"
  on public.reviews for insert to authenticated
  with check (author_id = auth.uid() and status = 'pending' and business_reply is null);
-- No public update/delete policy: moderation and reply actions should be implemented
-- via a trusted server/Edge Function with role checks, not from an untrusted browser.

create policy "Users can read their own profile"
  on public.profiles for select to authenticated using (id = auth.uid());
create policy "Users can create their own customer profile"
  on public.profiles for insert to authenticated
  with check (id = auth.uid() and role in ('customer','tradesperson'));
create policy "Users can update their own display name"
  on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid() and role in ('customer','tradesperson'));

create policy "Signed in users can report reviews"
  on public.review_reports for insert to authenticated
  with check (reporter_id = auth.uid());
create policy "Reporters can view their own reports"
  on public.review_reports for select to authenticated
  using (reporter_id = auth.uid());

-- Important before launch:
-- 1) Add an admin-only moderation path using a server-side Edge Function.
-- 2) Never expose the Supabase service_role key in browser code.
-- 3) Define and test account deletion, data retention, abuse controls, backups and privacy notices.
-- 4) Keep verification labels blank until documented checks are genuinely completed.
