# Trade Stamped — launch starter

**Brand:** Trade Stamped  
**Slogan:** Stamped With Your Approval.  
**Launch area:** Widnes and nearby WA postcodes  
**Budget target:** £0 using free tiers

## What's included

- `index.html` — responsive homepage and interactive front-end prototype.
- `supabase/schema.sql` — starter database structure and row-level security policies for Supabase.

## Important: current state

The homepage is still a **prototype**. The sample businesses, ratings and review snippets are fictional. The current forms save demo entries to the visitor's browser only; they do not send information to Trade Stamped. The database schema is a foundation, not a connected backend. Do not advertise the site as a live review service until the database, moderation, privacy and account flows are implemented and tested.

## Free launch route

### 1. Publish the static homepage

1. Create/sign in to a GitHub account.
2. Create a new repository named `trade-stamped`.
3. Upload `index.html` from this folder to the repository root.
4. Open **Settings → Pages** in the repository.
5. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
6. GitHub Pages will show the public website address once deployment finishes.

A custom domain is optional and usually costs money; start with the free Pages address.

### 2. Create the database

1. Create a Supabase account and a new project on its free tier.
2. Open **SQL Editor → New query**.
3. Copy the full contents of `supabase/schema.sql` into the editor and run it.
4. Keep the project's URL and public anon/publishable key private to your own setup notes. The public key can be used in browser apps when row-level security is correctly configured; **never** put a `service_role` key in the website.

### 3. Before connecting real users

The front end needs to be wired to Supabase for sign-in, profile creation, profile submission, review submission and reading published listings. A trusted server-side moderation action is also required to approve/reject reviews and handle replies. The current HTML does not yet perform those calls. Once a Supabase project is created, its project URL and public anon/publishable key are the two settings needed to begin that integration.

### 4. Do not skip these launch safeguards

- Replace every fictional sample profile/review with genuine listings and clearly authorised content, or remove the demo cards.
- Write a complete UK GDPR privacy notice and terms; decide who is legally responsible for the service and publish contact details.
- Implement moderation, review reporting, a fair right of reply and an appeal process before public reviews go live.
- Do not show a “verified” badge unless a defined check has actually been completed. Say exactly what was checked.
- Test mobile layout, keyboard access, form validation, account deletion, security policies and backups.
- Never publish private phone numbers, addresses or other personal data without a proper basis and permission.

## Suggested first release scope

1. Public homepage and search/filter UI.
2. Customer/tradesperson accounts.
3. Tradesperson profile submission and owner editing.
4. Reviews held as `pending` until moderation.
5. Published-only public directory/reviews.
6. Reporting and right-of-reply workflow.
7. Basic admin moderation panel (server-side permissions required).

This starter is not legal advice or a production security audit.
